var constants_root = "http://197.85.191.92/gigguide/";
var constants_maxTracks = 2; // Note actual number of 3 but used because of reference to array position