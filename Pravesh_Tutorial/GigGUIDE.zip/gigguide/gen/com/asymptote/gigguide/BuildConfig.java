/** Automatically generated file. DO NOT MODIFY */
package com.asymptote.gigguide;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}